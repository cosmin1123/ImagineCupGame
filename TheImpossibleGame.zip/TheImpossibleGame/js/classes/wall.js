﻿function Wall(posX, posY, scale) {

    this.x = posX;
    this.y = posY;
    this.width = scale;
    this.height = scale;
}
